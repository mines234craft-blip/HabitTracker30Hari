HABIT TRACKER 30 HARI — PROYEK APLIKASI ANDROID

Proyek ini membungkus Habit Tracker asli ke dalam aplikasi Android menggunakan WebView. Checklist disimpan otomatis di penyimpanan aplikasi pada perangkat (localStorage) dan aplikasi dapat digunakan offline.

CARA MEMBUAT APK
1. Instal Android Studio pada komputer/laptop.
2. Ekstrak ZIP ini.
3. Buka Android Studio > Open, lalu pilih folder HabitTrackerAndroid.
4. Tunggu Gradle Sync selesai. Jika diminta, instal Android SDK Platform 35 dan gunakan JDK 17.
5. Pilih Build > Build Bundle(s) / APK(s) > Build APK(s).
6. APK hasil build biasanya berada di app/build/outputs/apk/debug/app-debug.apk.
7. Pindahkan APK ke HP Android dan instal. Jika diminta, izinkan instalasi dari sumber tersebut.

CATATAN
- ZIP ini adalah proyek Android Studio, bukan APK yang sudah dikompilasi. Kompilasi membutuhkan Android Studio/Android SDK.
- Aplikasi tidak meminta izin internet atau akun.
- Ekspor CSV pada aplikasi Android membuka pemilih lokasi penyimpanan.

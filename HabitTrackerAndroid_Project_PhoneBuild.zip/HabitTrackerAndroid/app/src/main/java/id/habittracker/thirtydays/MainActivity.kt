package id.habittracker.thirtydays

import android.app.Activity
import android.os.Bundle
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.webkit.WebViewClient
import android.webkit.WebSettings
import android.webkit.JavascriptInterface
import android.content.Intent
import android.net.Uri
import android.content.ActivityNotFoundException
import android.widget.Toast

class MainActivity : Activity() {
    private lateinit var webView: WebView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        webView = WebView(this)
        setContentView(webView)
        webView.webViewClient = WebViewClient()
        webView.webChromeClient = WebChromeClient()
        webView.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            allowFileAccess = true
            allowContentAccess = true
            cacheMode = WebSettings.LOAD_DEFAULT
        }
        webView.addJavascriptInterface(DownloadBridge(), "AndroidDownload")
        webView.loadUrl("file:///android_asset/index.html")
    }

    inner class DownloadBridge {
        @JavascriptInterface
        fun saveCsv(csv: String) {
            runOnUiThread {
                val intent = Intent(Intent.ACTION_CREATE_DOCUMENT).apply {
                    addCategory(Intent.CATEGORY_OPENABLE)
                    type = "text/csv"
                    putExtra(Intent.EXTRA_TITLE, "habit-tracker-30-hari.csv")
                }
                pendingCsv = csv
                try { startActivityForResult(intent, CREATE_FILE_REQUEST) }
                catch (_: ActivityNotFoundException) { Toast.makeText(this@MainActivity, "Tidak ada aplikasi pengelola file.", Toast.LENGTH_SHORT).show() }
            }
        }
    }

    private var pendingCsv: String? = null

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == CREATE_FILE_REQUEST && resultCode == RESULT_OK) {
            val uri: Uri? = data?.data
            if (uri != null) {
                contentResolver.openOutputStream(uri)?.bufferedWriter(Charsets.UTF_8)?.use { it.write(pendingCsv ?: "") }
                Toast.makeText(this, "Progres berhasil diekspor.", Toast.LENGTH_SHORT).show()
            }
        }
        pendingCsv = null
    }

    @Deprecated("Deprecated in Android API; retained for broad device compatibility")
    override fun onBackPressed() {
        if (webView.canGoBack()) webView.goBack() else super.onBackPressed()
    }

    companion object { private const val CREATE_FILE_REQUEST = 4102 }
}
